# Practico-3-EducacionIT
Integrantes: David Rodriguez y Martin Desch
